/* eslint-disable no-undef */
const assert = require('assert');

Feature('Liking Restaurant');

Before(({ I }) => {
  I.amOnPage('/#/favorite');
});

Scenario('Show Empty Like', ({ I }) => {
  I.seeElement('.notfound');
  I.see('Restaurant Favorit not found', '.notfound p');
});

Scenario('like and unlike one restaurant', async ({ I }) => {
  I.amOnPage('/');

  const searchRestoFirst = locate('#post-menu_picture').first();
  const restoTittle = await I.grabTextFrom('.post-menu_tittle');
  I.click(searchRestoFirst);

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorite');
  I.seeElement('.post-menu');

  const likedRestaurantMenu = locate('#post-menu_picture').first();
  const likedRestaurantTittle = await I.grabTextFrom('.post-menu_title');

  assert.strictEqual(restoTittle, likedRestaurantTittle);

  I.click(likedRestaurantMenu);

  I.seeElement('#likeButton');
  I.click('#likeButton');

  I.amOnPage('/#/favorite');

  I.seeElement('.notfound');
  I.see('Restaurant Favorit not found', '.notfound p');
});
