/* eslint-disable no-undef */
import { itActsAsFavoriteRestaurantModel } from './helper/contract/favoriteRestaurantContract';
import RestaurantIdb from '../src/scripts/data/RestauranIdb';

describe('Favorite Restaurant Idb Contract Test Implementation', () => {
  afterEach(async () => {
    (await RestaurantIdb.getAllRestaurants()).forEach(async (restaurant) => {
      await RestaurantIdb.deleteRestaurant(restaurant.id);
    });
  });

  itActsAsFavoriteRestaurantModel(RestaurantIdb);
});
