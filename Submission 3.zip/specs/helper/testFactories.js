/* eslint-disable import/prefer-default-export */
import LikeButtonInitiator from '../../src/scripts/utils/LikeButtonInitiator';
import RestaurantIdb from '../../src/scripts/data/RestauranIdb';

const createLikeButtonPresenterWithRestaurant = async (restaurant) => {
  await LikeButtonInitiator.init({
    likeButtonContainer: document.querySelector('#likeButtonContainer'),
    favoriteRestaurant: RestaurantIdb,
    data: {
      restaurant,
    },
  });
};

export { createLikeButtonPresenterWithRestaurant };
