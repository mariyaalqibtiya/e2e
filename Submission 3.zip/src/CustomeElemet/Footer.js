class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
      <footer>
          <a href="#" class="cpy">
          <p>Copyright &copy;2020 - Pingguin</p>
          </a>
      </footer>`;
  }
}

customElements.define('custom-footer', CustomFooter);
