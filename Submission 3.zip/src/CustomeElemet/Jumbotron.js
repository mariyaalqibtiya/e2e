class CustomJumbotron extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
      <div class="jumbotron">
        <picture tabindex="-1">
          <source media="(max-width: 600px)" srcset="./images/hero-image_1-small.jpg">
          <img tabindex="-1" src="./images/hero-image_1-large.jpg"
            alt="Gambar jumbotron">
        </picture>
        <div class="jumbotron__content">
            <h1 class="jumbotron__title">Welcome to Restaurant Pingguin</h1>
            <p class="jumbotron__tagline">Eats Freak Everyday</p>
            <ul id="sosmed" class="sosmed">
                <li>
                  <a href="https://www.instagram.com/maryaal_" aria-label="instagram"><i class="fab fa-instagram"></i></a>
                </li>
                <li>
                  <a href="https://www.youtube.com/channel/UCRZ3K21nCEK6Q3Ez8G_J_fg/channels" aria-label="youtube"><i class="fab fa-youtube"></i></a>
                </li>
                <li>
                  <a href="https://www.linkedin.com/in/mariya-alqibtia-373b00256/" aria-label="linkedin"><i class="fab fa-linkedin"></i></a>
                </li>
            </ul>
        </div>
      </div>
      `;
  }
}

customElements.define('custom-jumbotron', CustomJumbotron);
