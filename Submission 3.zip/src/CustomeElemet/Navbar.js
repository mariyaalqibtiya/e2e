class CustomFooter extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
      <nav>
      <a class="brand" href="/" alt="Hungry Apps">Restaurant Pinguin</a>
  
      <button id="hamburgerButton" class="hamburger" href="#" aria-label="navigation-menu"><i class='fas fa-bars'></i></button>
  
      <ul id="nav-menu" class="nav-menu">
        <li><a href="/" aria-label="Home">Home</a></li>
        <li>
          <a href="#/favorite" aria-label="Favorite">Favorite</a>
        </li>
        <li>
          <a href="https://www.linkedin.com/in/mariya-alqibtia-373b00256/" aria-label="About">About Us</a>
        </li>
      </ul>
    </nav>`;
  }
}

customElements.define('custom-navbar', CustomFooter);
