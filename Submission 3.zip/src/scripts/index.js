/* eslint-disable no-unused-vars */
/* eslint-disable import/no-unresolved */
/* eslint-disable import/extensions */
import 'regenerator-runtime'; /* for async await transpile */
import 'lazysizes';
import 'lazysizes/plugins/parent-fit/ls.parent-fit';
// css
import '../styles/style.css';
import App from './views/app';
import swRegister from './utils/sw_Register';
import { WebSocketInitiator } from './utils/WebsocketInitiator';
import CONFIG from './globals/Config';
import '../CustomeElemet/Navbar';
import '../CustomeElemet/Jumbotron';
import '../CustomeElemet/Footer';

const START = 10;
const NUMBER_OF_IMAGES = 100;

const app = new App({
  button: document.querySelector('#hamburgerButton'),
  drawer: document.querySelector('#nav-menu'),
  content: document.querySelector('#main-content'),
});

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
  swRegister();
  WebSocketInitiator.init(CONFIG.WEB_SOCKET_SERVER);
});
