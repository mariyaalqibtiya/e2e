import Home from '../views/pages/Home';
import Like from '../views/pages/Like';
import Detail from '../views/pages/Detail';

const routes = {
  '/': Home,
  '/favorite': Like,
  '/restaurant/:id': Detail,
};

export default routes;
