/* eslint-disable import/prefer-default-export */
import NotificationHelper from './NotificationHelper';

const WebSocketInitiator = {
  init(url) {
    const socket = new WebSocket(url);
    socket.onmessage = this._onMessageHandler;
  },

  _onMessageHandler(message) {
    const restaurants = JSON.parse(message.data);

    NotificationHelper.sendNotification({
      title: restaurants.name,
      options: {
        body: restaurants.review,
        icon: '/icons/192x192.png',
      },
    });
  },
};

export { WebSocketInitiator };
