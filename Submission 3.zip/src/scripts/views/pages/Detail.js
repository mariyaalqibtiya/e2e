/* eslint-disable comma-dangle */
/* eslint-disable operator-linebreak */
import RestaurantSource from '../../data/RestauranSource';
import {
  createDetailPageContent,
  createLoadingTemplate,
} from '../templates/TemplateCreator';
import UrlParser from '../../routes/Url_Parser';
import LikeButtonInitiator from '../../utils/LikeButtonInitiator';
import RestaurantIdb from '../../data/RestauranIdb';

const Detail = {
  async render() {
    return `
    <div id="loading"></div>
    <div tabindex="0" id="restaurant" class="restaurant">
      <div tabindex="0" id="restaurant-detail" class="restaurant">
      </div>
      <div class="like" id="likeButtonContainer"></div>f
    </div>
    `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const restaurantAll = document.querySelector('#restaurant');
    const restaurantContainer = document.querySelector('#restaurant-detail');
    const loading = document.querySelector('#loading');

    restaurantAll.style.display = 'block';
    loading.innerHTML = createLoadingTemplate();

    try {
      const data = await RestaurantSource.detail(url.id);

      restaurantContainer.innerHTML += createDetailPageContent(
        data.restaurant
      );

      LikeButtonInitiator.init({
        likeButtonContainer: document.querySelector('#likeButtonContainer'),
        favoriteRestaurant: RestaurantIdb,
        data,
      });

      restaurantContainer.style.display = 'block';
      loading.style.display = 'none';
    } catch (error) {
      console.log(error);
    }
  },
};

export default Detail;
