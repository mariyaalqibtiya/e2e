import RestaurantSource from '../../data/RestauranSource';
import { createHomePageContent } from '../templates/TemplateCreator';

const Home = {
  async render() {
    return `
    <custom-jumbotron></custom-jumbotron>
    <section id="restaurant" class="content">
      <h1 id="content" tabindex="0" class="content_tagline" aria label="Explore Your Restaurant">Explore Your Restaurant</h1>
      <div class="form">
        <div class="list">
          <div class="menu" id="menulist"> </div>
        </div>
      </div>
    </section>
    `;
  },

  async afterRender() {
    const restaurants = await RestaurantSource.home();
    const restaurantList = document.querySelector('#menulist');
    restaurants.forEach((restaurant) => {
      restaurantList.innerHTML += createHomePageContent(restaurant);
    });
  },
};

export default Home;
