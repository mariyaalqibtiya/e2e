/* eslint-disable import/no-unresolved */
/* eslint-disable import/extensions */
/* eslint-disable operator-linebreak */
import RestaurantIdb from '../../data/RestauranIdb';
import { createHomePageContent } from '../templates/TemplateCreator';

const Like = {
  async render() {
    return `
      <custom-jumbotron></custom-jumbotron>
      <section id="restaurant" class="content">
        <h1 id="content" tabindex="0" class="content_tagline" aria label="Favorite Restaurant">Favorite Restaurant</h1>
        <div class="form">
          <div class="list">
            <div class="menu" id="menulist"> </div>
          </div>
        </div>
      </section>
    `;
  },

  async afterRender() {
    const restaurants = await RestaurantIdb.getAllRestaurants();
    const restaurantsContainer = document.querySelector('#menulist');

    try {
      restaurants.forEach((restaurant) => {
        restaurantsContainer.innerHTML +=
          createHomePageContent(restaurant);
      });
      if (restaurants.length === 0) {
        restaurantsContainer.innerHTML += `
        <div class="notfound">
          <p>Restaurant Favorit not found</p>
        </div>
        `;
      }
    } catch (error) {
      console.log(error);
    }
  },
};

export default Like;
